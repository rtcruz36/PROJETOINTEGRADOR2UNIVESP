// Seletores de elementos HTML
const startButton = document.getElementById('start-app-btn');
const quizSection = document.getElementById('quiz-section');
const timeSection = document.getElementById('time-management-section');
const aiSection = document.getElementById('ai-section'); 
const quizContainer = document.querySelector('.quiz-container');

// SELETORES PARA O POMODORO
const timerDisplay = document.getElementById('timer-display');
const startBtn = document.getElementById('start-btn');
const pauseBtn = document.getElementById('pause-btn');
const resetBtn = document.getElementById('reset-btn');

// SELETORES PARA A IA
const aiInput = document.getElementById('ai-input');
const askAiBtn = document.getElementById('ask-ai-btn');
const aiChatLog = document.getElementById('ai-chat-log');

// --- Lógica do Quiz ---
const questions = [
    {
        question: "Qual a capital do Brasil?",
        answers: ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"],
        correctAnswer: "Brasília"
    },
    {
        question: "Quem pintou a Monalisa?",
        answers: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
        correctAnswer: "Leonardo da Vinci"
    },
    {
        question: "Em que ano o Brasil foi descoberto?",
        answers: ["1492", "1500", "1534", "1600"],
        correctAnswer: "1500"
    }
];

let currentQuestionIndex = 0;
let score = 0;

function showQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    const questionText = currentQuestion.question;
    const answers = currentQuestion.answers;

    quizContainer.innerHTML = `
        <h3>${questionText}</h3>
        <div class="options">
            ${answers.map(answer => `<button class="answer-btn">${answer}</button>`).join('')}
        </div>
        <p id="feedback"></p>
    `;

    const newAnswerButtons = quizContainer.querySelectorAll('.answer-btn');
    newAnswerButtons.forEach(button => {
        button.addEventListener('click', () => {
            checkAnswer(button.textContent.trim());
        });
    });
}

function checkAnswer(userChoice) {
    const currentQuestion = questions[currentQuestionIndex];
    const feedbackParagraph = document.getElementById('feedback');
    
    if (userChoice === currentQuestion.correctAnswer) {
        score++;
        feedbackParagraph.textContent = "Correto!";
        feedbackParagraph.style.color = "green";
    } else {
        feedbackParagraph.textContent = "Incorreto. A resposta correta era: " + currentQuestion.correctAnswer;
        feedbackParagraph.style.color = "red";
    }

    setTimeout(() => {
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            showQuestion();
        } else {
            showResults();
        }
    }, 1500);
}

function showResults() {
    quizContainer.innerHTML = `
        <h2>Quiz Concluído!</h2>
        <p>Você acertou ${score} de ${questions.length} perguntas.</p>
    `;
}

// --- Lógica do Pomodoro ---
let timer;
let timeInSeconds = 25 * 60;
let isPaused = true;

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

function updateTimerDisplay() {
    if (timerDisplay) { // Verificação de segurança
        timerDisplay.textContent = formatTime(timeInSeconds);
    }
}

function startTimer() {
    if (isPaused) {
        isPaused = false;
        timer = setInterval(() => {
            timeInSeconds--;
            if (timeInSeconds < 0) {
                clearInterval(timer);
                alert("Pomodoro concluído! Hora do descanso.");
                timeInSeconds = 25 * 60;
                isPaused = true;
            }
            updateTimerDisplay();
        }, 1000);
    }
}

function pauseTimer() {
    isPaused = true;
    clearInterval(timer);
}

function resetTimer() {
    pauseTimer();
    timeInSeconds = 25 * 60;
    updateTimerDisplay();
}

startBtn.addEventListener('click', startTimer);
pauseBtn.addEventListener('click', pauseTimer);
resetBtn.addEventListener('click', resetTimer);

// --- Lógica da IA / Chat ---
function addMessage(text, sender) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message');
    
    if (sender === 'user') {
        messageDiv.classList.add('user-message');
    } else {
        messageDiv.classList.add('ia-message');
    }

    messageDiv.innerHTML = `<p>${text}</p>`;
    aiChatLog.appendChild(messageDiv);
    aiChatLog.scrollTop = aiChatLog.scrollHeight; // Rola o chat para baixo
}

// Evento do botão Perguntar
askAiBtn.addEventListener('click', () => {
    const userQuestion = aiInput.value.trim();
    if (userQuestion === "") {
        return;
    }

    // 1. Adiciona a mensagem do usuário
    addMessage(userQuestion, 'user');
    aiInput.value = ""; 
    
    // 2. Simula o "Pensando..."
    addMessage("Pensando...", 'ia');

    // 3. Simula o tempo de resposta e adiciona a resposta
    setTimeout(() => {
        // Frase final combinada com seu pedido de simplificação
        const simulatedResponse = "Simulação de resposta.";
        
        // Remove a mensagem de "Pensando..."
        if (aiChatLog.lastElementChild.textContent === 'Pensando...') { 
             aiChatLog.lastElementChild.remove();
        }
       
        // Adiciona a resposta final
        addMessage(simulatedResponse, 'ia');

    }, 1500); // 1.5 segundos de espera simulada
});


// --- Evento para iniciar a aplicação (Botão "Começar a usar!") ---
startButton.addEventListener('click', () => {
    quizSection.style.display = 'block';
    timeSection.style.display = 'block';
    aiSection.style.display = 'block'; // Torna visível a seção de IA
    startButton.style.display = 'none';

    showQuestion();
    updateTimerDisplay();
    // Mensagem inicial da IA ao clicar no botão
    addMessage("Olá! Pode me perguntar sobre qualquer tema relacionado aos seus estudos.", "ia");
});

document.addEventListener('DOMContentLoaded', () => {
    // Isso garante que o tempo do Pomodoro apareça antes do clique no botão
    if (timerDisplay) { 
        updateTimerDisplay();
    }
});